# Limitations and interpretation

- **Synthetic lab only.** Two disposable instances and two source rows model
  ordinary tables and `bigserial` sequences in one schema. This is not a client
  incident, performance benchmark or proof of production readiness.
- **Exact build and architecture.** The observed result is PostgreSQL 18.4
  (`Debian 18.4-1.pgdg12+1`), Linux/amd64, with Docker 28.4.0. No other release,
  architecture, cross-version restore or managed PostgreSQL service was tested.
- **Privileges, not authentication.** Application and owner roles are `NOLOGIN`.
  Local administrative connections switch effective roles with `SET ROLE`.
  Tests verify the non-superuser `current_user`, application role attributes and
  absence of owner membership. They do not test real application logins,
  credentials, poolers, TLS or connection-time `CONNECT`. The migration fix uses
  `SET SESSION AUTHORIZATION migration_role` before `SET ROLE target_owner` to
  exercise membership rather than administrator privilege for that role switch.
- **Fresh target policy.** Every target database starts from `template0`.
  `--no-acl` skips archived privilege commands; it is not a revocation of
  built-in privileges, existing target grants, owner powers, role membership or
  target default privileges. These pre-existing cases need separate analysis.
- **Database ownership is separate.** The runner pre-creates the databases and
  restores without `--create`. It tests schema/relation ownership and object
  ACLs; it does not claim that `--no-owner` remaps a pre-existing database owner.
- **Roles are cluster-wide.** Source role names are initially absent at the
  destination, then created explicitly for preservation. They remain present
  for diagnostic and remapped databases in the destination cluster. Assertions
  prove they receive no archived app permissions in the remapped database.
  Role definitions, memberships and passwords are not recovered by `pg_dump`.
- **Defaults depend on creator.** The new policy intentionally covers all future
  tables and sequences created by `target_owner` in `app`, in that database.
  The lab has no global default grants to layer on top. Existing objects require
  named grants. Objects made while the current role is `migration_role` do not
  receive `target_owner`'s defaults, even with membership. The earlier
  migration-owned table receives a scoped ACL repair and remains owned by
  `migration_role`; transferring its ownership was not part of that repair.
- **Sequence semantics.** Generated INSERTs exercise `nextval` with sequence
  `USAGE`. Actual `setval` denial is checked; absence of sequence `UPDATE` is
  checked on all positive table scenarios. INSERT probes are rolled back,
  but sequence allocations are not rolled back. Gapless IDs are not expected.
  Identity columns were intentionally not used or generalised from this test.
- **Excluded features.** No RLS, extensions, security-definer functions,
  partitioning, large objects, tablespaces, role passwords, grant-option chains,
  concurrent DDL, partial archive selection, parallel restore, or physical backup
  recovery was tested. Do not apply the restore commands to untrusted archives.
- **Execution and review.** Tools executed the lab; model assistance produced
  scripts, analysis and prose. The additional review was automated, not human
  peer review.
- **Cleanup scope.** Normal cleanup was verified; forced termination, second
  interruption and daemon outage were not induced. Such failures can prevent
  cleanup. Capture of a server log is warning-only in the runner; both logs are
  present and integrity-checked in the canonical run. Docker image layers are
  cached locally; no live lab container or persistent database remains.
- **Documentation scope.** `/docs/18/` is the maintained major-version manual.
  Critical semantics were cross-checked against the official `REL_18_4` source
  documentation and the relevant archive-reader code, as linked in the notes.
  Runtime output and image digest identify the executed build.
