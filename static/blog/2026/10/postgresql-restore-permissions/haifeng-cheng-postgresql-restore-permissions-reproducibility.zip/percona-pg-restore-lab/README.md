# PostgreSQL restore-permissions reproducibility package

This package contains the recorded 13 October 2026 experiment and the inputs
needed to repeat it. All data is synthetic. Model assistance and automated
execution were used; no human execution or peer review is claimed.

The public package was prepared on 28 October 2026. Experiment scripts, SQL,
outputs, logs and per-run integrity manifests are unchanged; this packaging
step did not rerun the experiment.

## Verified result

The canonical fresh run is `outputs/run-03`: **PASS, 70 checks**, completed at
`2026-10-13T08:10:20.481514+00:00`. It records 118 command outcomes, including
12 expected SQLSTATE `42501` permission denials and the expected missing-role
restore failure. The 70 checks comprise these 13 expected failures and 57
positive/state checks. Source and destination containers were removed at the end.

Tested server and client binaries: `18.4 (Debian 18.4-1.pgdg12+1)` on the
`linux/amd64` Debian 12 PostgreSQL image. Docker client and engine: `28.4.0`.

The image is locked in `image.lock`:

```text
postgres@sha256:882236b897e39051d2368c5ccc6cda944904723506b2dfc97f2a8f5bc9afa382
```

The tag used to obtain it was `postgres:18.4-bookworm`. The selected amd64 image
ID was `sha256:526573c93ea530a230b553cc513075ab9d70b63bfd2300ef5eb5ad1cafbbc595`.
This is an exact tested version, not a recommendation or claim to be latest.

## Reproduce from a new directory

Prerequisites: Python 3 (standard library only), an accessible **local** Docker
engine capable of running this Linux/amd64 image, and enough memory/disk for two
tiny PostgreSQL containers. Do not point Docker at a production or shared remote
daemon. Image acquisition requires network access if it is not already cached.
No paid service, account, password or production connection is required.

From the extracted lab directory:

```sh
docker pull "$(cat image.lock)"
python3 scripts/run_lab.py --output outputs/my-fresh-run
```

The output directory must not already exist. The runner refuses to overwrite
earlier evidence. Exit `0` and `results.json` status `PASS` mean that all checks
and cleanup completed successfully. Any unexpected exit, error text, assertion
or cleanup result produces failure. See `CHECKLIST.md` for exact criteria.

The runner starts two newly initialised clusters, creates roles and databases
inside them, dumps once, and restores that archive into three fresh target
databases. Every PostgreSQL command, SQL input, output and exit status is
recorded. It verifies the archive's SHA-256 after transferring it. SQL grants are
limited to named objects or the explicitly described future-object policy.

The containers have no network and no published ports. PostgreSQL listens only
on a private Unix socket. Data lives under `/lab` on tmpfs. New clusters use peer
authentication for local connections and reject host authentication. The runner
does not alter the host's security or network configuration. Test owner/app roles
are `NOLOGIN`; the bootstrap `postgres` role is used only inside the disposable
clusters. Container image layers remain in the local Docker cache for reuse;
the databases, synthetic roles and anonymous container volumes are removed.

The runner cleans up its own randomly named containers on normal completion,
ordinary exceptions and a first Ctrl-C. A killed process or unavailable Docker
daemon can prevent cleanup. If that happens, read the exact container names in
that run's `transcript.log`, then remove **only those containers** with
`docker rm --force --volumes EXACT_NAME`. Never use a broad Docker prune.

## Files

| Path | Purpose |
| --- | --- |
| `scripts/run_lab.py` | End-to-end executable lab and pass/fail assertions |
| `sql/source.sql` | Synthetic source objects, existing grants and owner-specific defaults |
| `sql/inventory.sql` | Ownership, ACL, default-ACL and role inspection |
| `image.lock` | Digest-pinned PostgreSQL image |
| `CHECKLIST.md` | Human-readable criteria and all 70 actual assertion outcomes |
| `LIMITATIONS.md` | What was and was not tested |
| `references/source-notes.md` | Official PostgreSQL 18 / REL_18_4 sources |
| `outputs/run-03/results.json` | Canonical machine-readable status and check records |
| `outputs/run-03/checklist.tsv` | Canonical assertion table |
| `outputs/run-03/transcript.log` | Complete exact commands, SQL, stdout, stderr and exits |
| `outputs/run-03/commands/` | Individual command metadata, SQL inputs and raw outputs |
| `outputs/run-03/source.dump` | Real custom-format synthetic archive consumed by all branches |
| `outputs/run-03/archive-list.txt`, `archive.sql` | Archive inventory and readable rendering |
| `outputs/run-03/reproduction-inputs/` | Exact script, lock and SQL snapshots used for this run |
| `outputs/run-03/source-server.log`, `target-server.log` | Actual PostgreSQL server logs |
| `outputs/run-03/SHA256SUMS` | Integrity manifest for canonical execution evidence |
| `outputs/run-01/` | Retained initial failed transfer attempt; not evidence of a passing lab |
| `outputs/run-02/` | Intermediate passing 61-check run before additional assertions |
| `logs/` | Image pull, Docker version and per-run console logs |

To verify canonical evidence integrity:

```sh
cd outputs/run-03
sha256sum -c SHA256SUMS
```

The first run stopped because Docker's copy operation reported the tmpfs archive
path absent, despite successful `pg_dump`. Its five recorded checks included
successful cleanup. The final runner streams the archive through `docker exec`
and verifies its bytes, avoiding that environment-specific copy issue. This
history is retained rather than presented as a successful first attempt.

Only the scoped lab directory was used. No unrelated repository or production
system was read or modified. Follow the companion limitations before adapting
any SQL to a real system.
