# Reproducible pass/fail checklist

Canonical evidence: `outputs/run-03`, PostgreSQL 18.4, **70/70 PASS**.
Run the command in `README.md` with a new output directory to repeat it.

A positive SQL assertion must return exactly `t` with exit 0. The runner uses
non-interactive `psql` with `ON_ERROR_STOP=1`; a permission negative must exit 3,
include SQLSTATE `42501`, and match its specific permission error. The missing-role `pg_restore` must exit 1 and name
`legacy_owner`; the next check verifies the transaction left no `app` schema.
Every command's expected status/text is checked, not merely the final row count.
An unexpected error stops the run, triggers cleanup, and records overall FAIL.

The 70 assertions are in addition to command-level checks (118 command records
in this run). Twelve permission errors and one restore failure are expected
success criteria, not unexpected failures. Each evidence number links to the
exact command, expectation and status; sibling `.stdin.sql`, `.stdout` and
`.stderr` files hold the input and raw outputs. The archive-transfer input is
base64 despite the generic `.stdin.sql` suffix.

## Required outcomes

| Area | Pass condition | Fail condition |
| --- | --- | --- |
| Environment | Server 180004, pinned image, no TCP listener | Version differs, missing Docker/database capability or exposed server |
| Preservation | Source schema/relation owners and app grants restored; owner-created future table works | Missing/changed owners, app operations fail, or future defaults absent |
| Missing roles | Expected restore failure, then no restored schema | Unexpected success or partial schema remains |
| Ownership only | Restoring role owns objects; old grantee and creator defaults remain | Mistaken claim of full role-name mapping |
| Explicit remap | New object owner, no old app grants/default ACLs; intended app rights added explicitly | Old rights assumed translated or broad grants used to hide dependency |
| Existing objects | Schema, table and sequence failures match; each named grant repairs its dependency | Generic error accepted or sequence dependency untested |
| Future objects | Defaults tied to actual creator; later owner-created table supports SELECT/generated INSERT | Existing table assumed repaired or member role assumed to inherit defaults |
| Restriction | App denied table UPDATE/DELETE, schema CREATE and sequence setval | Unrequested power succeeds |
| Data and cleanup | Two original rows intact in all three target DBs; own containers removed | Data changed or disposable resource cleanup unverified |

## Actual assertion ledger

| # | Check | Observed | Command evidence |
| --- | --- | --- | --- |
| 1 | server pinned to 18.4 | PASS | [016](outputs/run-03/commands/016.json) |
| 2 | server version is 180004: source | PASS | [017](outputs/run-03/commands/017.json) |
| 3 | no TCP listener: source | PASS | [018](outputs/run-03/commands/018.json) |
| 4 | server version is 180004: target | PASS | [019](outputs/run-03/commands/019.json) |
| 5 | no TCP listener: target | PASS | [020](outputs/run-03/commands/020.json) |
| 6 | source has two synthetic rows | PASS | [023](outputs/run-03/commands/023.json) |
| 7 | preserve requires source roles | PASS | [032](outputs/run-03/commands/032.json) |
| 8 | failed preserve restored no schema (transaction rolled back) | PASS | [033](outputs/run-03/commands/033.json) |
| 9 | preserved object ownership | PASS | [036](outputs/run-03/commands/036.json) |
| 10 | preserved creator default ACLs | PASS | [037](outputs/run-03/commands/037.json) |
| 11 | preserved existing table: effective role | PASS | [038](outputs/run-03/commands/038.json) |
| 12 | preserved existing table: SELECT | PASS | [039](outputs/run-03/commands/039.json) |
| 13 | preserved existing table: generated INSERT and RETURNING | PASS | [040](outputs/run-03/commands/040.json) |
| 14 | preserved existing table: table and sequence rights | PASS | [041](outputs/run-03/commands/041.json) |
| 15 | preserved future table: effective role | PASS | [043](outputs/run-03/commands/043.json) |
| 16 | preserved future table: SELECT | PASS | [044](outputs/run-03/commands/044.json) |
| 17 | preserved future table: generated INSERT and RETURNING | PASS | [045](outputs/run-03/commands/045.json) |
| 18 | preserved future table: table and sequence rights | PASS | [046](outputs/run-03/commands/046.json) |
| 19 | no-owner alone uses restoring role for object owner | PASS | [049](outputs/run-03/commands/049.json) |
| 20 | no-owner alone retains legacy grantee | PASS | [050](outputs/run-03/commands/050.json) |
| 21 | no-owner alone retains legacy default-ACL creator | PASS | [051](outputs/run-03/commands/051.json) |
| 22 | no-owner alone does not map target_app | PASS | [052](outputs/run-03/commands/052.json) |
| 23 | no-owner alone retains old app access: effective role | PASS | [053](outputs/run-03/commands/053.json) |
| 24 | no-owner alone retains old app access: SELECT | PASS | [054](outputs/run-03/commands/054.json) |
| 25 | no-owner alone retains old app access: generated INSERT and RETURNING | PASS | [055](outputs/run-03/commands/055.json) |
| 26 | no-owner alone retains old app access: table and sequence rights | PASS | [056](outputs/run-03/commands/056.json) |
| 27 | old creator defaults do not apply to restoring role | PASS | [058](outputs/run-03/commands/058.json) |
| 28 | old creator defaults do not grant new sequence usage | PASS | [059](outputs/run-03/commands/059.json) |
| 29 | remapped schema and all relations owned by target_owner | PASS | [062](outputs/run-03/commands/062.json) |
| 30 | no-acl excludes source default ACLs and source application grants | PASS | [063](outputs/run-03/commands/063.json) |
| 31 | remap before schema grant | PASS | [064](outputs/run-03/commands/064.json) |
| 32 | schema usage is not table SELECT | PASS | [066](outputs/run-03/commands/066.json) |
| 33 | table SELECT after scoped grant | PASS | [068](outputs/run-03/commands/068.json) |
| 34 | table INSERT does not grant sequence usage | PASS | [069](outputs/run-03/commands/069.json) |
| 35 | remapped existing table: effective role | PASS | [071](outputs/run-03/commands/071.json) |
| 36 | remapped existing table: SELECT | PASS | [072](outputs/run-03/commands/072.json) |
| 37 | remapped existing table: generated INSERT and RETURNING | PASS | [073](outputs/run-03/commands/073.json) |
| 38 | remapped existing table: table and sequence rights | PASS | [074](outputs/run-03/commands/074.json) |
| 39 | app cannot UPDATE table | PASS | [075](outputs/run-03/commands/075.json) |
| 40 | app cannot DELETE table | PASS | [076](outputs/run-03/commands/076.json) |
| 41 | app cannot setval sequence | PASS | [077](outputs/run-03/commands/077.json) |
| 42 | app cannot CREATE in schema | PASS | [078](outputs/run-03/commands/078.json) |
| 43 | new table without defaults | PASS | [080](outputs/run-03/commands/080.json) |
| 44 | defaults do not repair pre-existing table | PASS | [082](outputs/run-03/commands/082.json) |
| 45 | defaults do not repair pre-existing sequence | PASS | [083](outputs/run-03/commands/083.json) |
| 46 | explicitly repaired early table: effective role | PASS | [085](outputs/run-03/commands/085.json) |
| 47 | explicitly repaired early table: SELECT | PASS | [086](outputs/run-03/commands/086.json) |
| 48 | explicitly repaired early table: generated INSERT and RETURNING | PASS | [087](outputs/run-03/commands/087.json) |
| 49 | explicitly repaired early table: table and sequence rights | PASS | [088](outputs/run-03/commands/088.json) |
| 50 | remapped future owner-created table: effective role | PASS | [089](outputs/run-03/commands/089.json) |
| 51 | remapped future owner-created table: SELECT | PASS | [090](outputs/run-03/commands/090.json) |
| 52 | remapped future owner-created table: generated INSERT and RETURNING | PASS | [091](outputs/run-03/commands/091.json) |
| 53 | remapped future owner-created table: table and sequence rights | PASS | [092](outputs/run-03/commands/092.json) |
| 54 | target defaults belong to target_owner only | PASS | [093](outputs/run-03/commands/093.json) |
| 55 | membership does not change creating role | PASS | [096](outputs/run-03/commands/096.json) |
| 56 | owner defaults are not inherited by a member creator | PASS | [097](outputs/run-03/commands/097.json) |
| 57 | migration SET ROLE creates as default-ACL owner | PASS | [099](outputs/run-03/commands/099.json) |
| 58 | migration with explicit owner role: effective role | PASS | [100](outputs/run-03/commands/100.json) |
| 59 | migration with explicit owner role: SELECT | PASS | [101](outputs/run-03/commands/101.json) |
| 60 | migration with explicit owner role: generated INSERT and RETURNING | PASS | [102](outputs/run-03/commands/102.json) |
| 61 | migration with explicit owner role: table and sequence rights | PASS | [103](outputs/run-03/commands/103.json) |
| 62 | explicitly repaired migration table: effective role | PASS | [105](outputs/run-03/commands/105.json) |
| 63 | explicitly repaired migration table: SELECT | PASS | [106](outputs/run-03/commands/106.json) |
| 64 | explicitly repaired migration table: generated INSERT and RETURNING | PASS | [107](outputs/run-03/commands/107.json) |
| 65 | explicitly repaired migration table: table and sequence rights | PASS | [108](outputs/run-03/commands/108.json) |
| 66 | lab_preserved retains exactly the original data | PASS | [109](outputs/run-03/commands/109.json) |
| 67 | lab_owner_only retains exactly the original data | PASS | [110](outputs/run-03/commands/110.json) |
| 68 | lab_remapped retains exactly the original data | PASS | [111](outputs/run-03/commands/111.json) |
| 69 | app has no owner-role membership or elevated attributes | PASS | [112](outputs/run-03/commands/112.json) |
| 70 | disposable containers and anonymous volumes removed | PASS | [118](outputs/run-03/commands/118.json) |

All raw output is retained, including expected failures. See `LIMITATIONS.md` before adapting the lab.
