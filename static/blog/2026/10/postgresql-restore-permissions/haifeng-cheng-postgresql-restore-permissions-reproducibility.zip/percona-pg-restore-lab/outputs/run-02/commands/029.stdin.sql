CREATE ROLE target_owner NOLOGIN;
CREATE ROLE target_app NOLOGIN;
CREATE ROLE migration_role NOLOGIN;
CREATE DATABASE lab_preserved TEMPLATE template0;
CREATE DATABASE lab_owner_only TEMPLATE template0;
CREATE DATABASE lab_remapped OWNER target_owner TEMPLATE template0;
