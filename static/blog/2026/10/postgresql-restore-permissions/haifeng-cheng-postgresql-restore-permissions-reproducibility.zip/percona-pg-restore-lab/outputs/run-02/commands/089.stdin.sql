SELECT pg_get_userbyid(relowner)='target_owner' FROM pg_class WHERE oid='app.migration_fixed_widgets'::regclass;
