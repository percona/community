SET ROLE target_app; SELECT count(*)=2 FROM app.widgets;
