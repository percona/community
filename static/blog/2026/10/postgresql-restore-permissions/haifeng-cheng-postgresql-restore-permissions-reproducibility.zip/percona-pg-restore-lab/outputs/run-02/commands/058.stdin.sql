SET ROLE target_owner; GRANT SELECT, INSERT ON TABLE app.widgets TO target_app;
