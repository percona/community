SELECT current_setting('listen_addresses') = ''; 
