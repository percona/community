SET ROLE migration_role;
GRANT SELECT, INSERT ON TABLE app.migration_widgets TO target_app;
GRANT USAGE ON SEQUENCE app.migration_widgets_id_seq TO target_app;
