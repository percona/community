CREATE DATABASE lab_source TEMPLATE template0;
