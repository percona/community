SET ROLE target_app;
INSERT INTO app.widgets(payload) VALUES ('synthetic-denied');
