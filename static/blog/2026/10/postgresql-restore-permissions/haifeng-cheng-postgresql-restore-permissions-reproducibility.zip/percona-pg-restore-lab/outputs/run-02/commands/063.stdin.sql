SET ROLE target_app; SELECT count(*) >= 0 FROM app.widgets;
