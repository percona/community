SET SESSION AUTHORIZATION migration_role;
SET ROLE target_owner;
CREATE TABLE app.migration_fixed_widgets (id bigserial PRIMARY KEY, payload text NOT NULL);
