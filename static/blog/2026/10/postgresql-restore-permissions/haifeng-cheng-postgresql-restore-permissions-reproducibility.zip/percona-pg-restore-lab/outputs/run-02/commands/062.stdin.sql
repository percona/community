SET ROLE target_app; SELECT current_user = 'target_app' AND NOT (SELECT rolsuper FROM pg_roles WHERE rolname = current_user);
