SET ROLE target_app; BEGIN; INSERT INTO app.migration_widgets(payload) VALUES ('synthetic-probe') RETURNING id > 0; ROLLBACK;
