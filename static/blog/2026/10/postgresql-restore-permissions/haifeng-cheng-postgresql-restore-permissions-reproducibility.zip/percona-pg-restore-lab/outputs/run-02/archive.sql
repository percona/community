--
-- PostgreSQL database dump
--

\restrict dc5f8jCBsDM2l3HVZ1hn8iu3ll039dnT7TedVVQz1Eo7VxBqApnueeF1zVuhwW3

-- Dumped from database version 18.4 (Debian 18.4-1.pgdg12+1)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: legacy_owner
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO legacy_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: widgets; Type: TABLE; Schema: app; Owner: legacy_owner
--

CREATE TABLE app.widgets (
    id bigint NOT NULL,
    payload text NOT NULL
);


ALTER TABLE app.widgets OWNER TO legacy_owner;

--
-- Name: widgets_id_seq; Type: SEQUENCE; Schema: app; Owner: legacy_owner
--

CREATE SEQUENCE app.widgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE app.widgets_id_seq OWNER TO legacy_owner;

--
-- Name: widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: app; Owner: legacy_owner
--

ALTER SEQUENCE app.widgets_id_seq OWNED BY app.widgets.id;


--
-- Name: widgets id; Type: DEFAULT; Schema: app; Owner: legacy_owner
--

ALTER TABLE ONLY app.widgets ALTER COLUMN id SET DEFAULT nextval('app.widgets_id_seq'::regclass);


--
-- Data for Name: widgets; Type: TABLE DATA; Schema: app; Owner: legacy_owner
--

COPY app.widgets (id, payload) FROM stdin;
1	synthetic-alpha
2	synthetic-beta
\.


--
-- Name: widgets_id_seq; Type: SEQUENCE SET; Schema: app; Owner: legacy_owner
--

SELECT pg_catalog.setval('app.widgets_id_seq', 2, true);


--
-- Name: widgets widgets_pkey; Type: CONSTRAINT; Schema: app; Owner: legacy_owner
--

ALTER TABLE ONLY app.widgets
    ADD CONSTRAINT widgets_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: legacy_owner
--

GRANT USAGE ON SCHEMA app TO legacy_app;


--
-- Name: TABLE widgets; Type: ACL; Schema: app; Owner: legacy_owner
--

GRANT SELECT,INSERT ON TABLE app.widgets TO legacy_app;


--
-- Name: SEQUENCE widgets_id_seq; Type: ACL; Schema: app; Owner: legacy_owner
--

GRANT USAGE ON SEQUENCE app.widgets_id_seq TO legacy_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: app; Owner: legacy_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE legacy_owner IN SCHEMA app GRANT USAGE ON SEQUENCES TO legacy_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: app; Owner: legacy_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE legacy_owner IN SCHEMA app GRANT SELECT,INSERT ON TABLES TO legacy_app;


--
-- PostgreSQL database dump complete
--

\unrestrict dc5f8jCBsDM2l3HVZ1hn8iu3ll039dnT7TedVVQz1Eo7VxBqApnueeF1zVuhwW3

