SET ROLE legacy_app; SELECT count(*) >= 0 FROM app.widgets;
