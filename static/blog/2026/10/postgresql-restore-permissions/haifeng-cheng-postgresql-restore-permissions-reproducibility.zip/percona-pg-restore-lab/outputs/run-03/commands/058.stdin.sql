SET ROLE legacy_app;
SELECT * FROM app.owner_only_future;
