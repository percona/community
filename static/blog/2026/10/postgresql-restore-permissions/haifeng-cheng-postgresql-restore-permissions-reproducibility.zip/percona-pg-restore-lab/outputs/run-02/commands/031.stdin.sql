SELECT NOT EXISTS (SELECT FROM pg_namespace WHERE nspname='app');
