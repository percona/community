SET ROLE target_app; BEGIN; INSERT INTO app.future_widgets(payload) VALUES ('synthetic-probe') RETURNING id > 0; ROLLBACK;
