SET ROLE target_app;
SELECT * FROM app.migration_widgets;
