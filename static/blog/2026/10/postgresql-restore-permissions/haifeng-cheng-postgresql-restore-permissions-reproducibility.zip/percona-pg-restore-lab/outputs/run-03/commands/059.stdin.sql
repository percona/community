SELECT NOT has_sequence_privilege('legacy_app','app.owner_only_future_id_seq','USAGE');
