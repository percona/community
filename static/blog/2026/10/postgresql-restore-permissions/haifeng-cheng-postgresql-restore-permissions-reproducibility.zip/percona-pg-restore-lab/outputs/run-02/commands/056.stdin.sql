SET ROLE target_owner; GRANT USAGE ON SCHEMA app TO target_app;
