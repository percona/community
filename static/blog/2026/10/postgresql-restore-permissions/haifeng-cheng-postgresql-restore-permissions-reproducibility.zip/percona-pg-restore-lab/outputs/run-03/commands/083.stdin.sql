SELECT NOT has_sequence_privilege('target_app','app.early_widgets_id_seq','USAGE');
