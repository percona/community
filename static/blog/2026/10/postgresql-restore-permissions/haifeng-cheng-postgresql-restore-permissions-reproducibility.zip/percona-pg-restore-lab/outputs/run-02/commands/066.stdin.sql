SET ROLE target_app;
UPDATE app.widgets SET payload='synthetic-denied' WHERE id=1;
