SET ROLE target_app;
DELETE FROM app.widgets WHERE id=1;
