SELECT array_agg(payload ORDER BY id) = ARRAY['synthetic-alpha','synthetic-beta'] FROM app.widgets;
