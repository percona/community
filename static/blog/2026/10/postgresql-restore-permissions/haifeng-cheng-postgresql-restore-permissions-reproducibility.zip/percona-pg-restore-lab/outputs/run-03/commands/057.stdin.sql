CREATE TABLE app.owner_only_future (id bigserial PRIMARY KEY, payload text NOT NULL);
