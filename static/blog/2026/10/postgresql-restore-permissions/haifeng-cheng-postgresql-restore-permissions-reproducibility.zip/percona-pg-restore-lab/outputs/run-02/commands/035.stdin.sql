SELECT count(*)=2 AND bool_and(pg_get_userbyid(defaclrole)='legacy_owner') FROM pg_default_acl;
