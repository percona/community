#!/usr/bin/env python3
"""Fresh, disposable PG18.4 lab. Python stdlib + a local Docker engine only."""
import argparse
import base64
import datetime as dt
import hashlib
import json
import pathlib
import shlex
import subprocess
import sys
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[1]
IMAGE = (ROOT / 'image.lock').read_text().strip()
PLATFORM = 'linux/amd64'


class Lab:
    def __init__(self, output):
        self.out = output.resolve()
        self.out.mkdir(parents=True, exist_ok=False)
        (self.out / 'commands').mkdir()
        inputs = self.out / 'reproduction-inputs'
        inputs.mkdir()
        for path in [pathlib.Path(__file__), ROOT / 'image.lock',
                     ROOT / 'sql/source.sql', ROOT / 'sql/inventory.sql']:
            (inputs / path.name).write_bytes(path.read_bytes())
        self.log = (self.out / 'transcript.log').open('w', buffering=1)
        self.rows = []
        self.n = 0
        self.containers = []
        self.prefix = 'percona-restore-' + uuid.uuid4().hex[:10]

    def command(self, args, stdin=None, expected=0, contains=None):
        self.n += 1
        stem = f'{self.n:03d}'
        rendered = shlex.join(map(str, args))
        if stdin is not None:
            (self.out / 'commands' / (stem + '.stdin.sql')).write_text(stdin)
        self.log.write(f'\n[{stem}] $ {rendered}\n')
        if stdin is not None:
            self.log.write('--- stdin ---\n' + stdin + '\n--- end stdin ---\n')
        result = subprocess.run(args, input=stdin, text=True, capture_output=True, timeout=120)
        (self.out / 'commands' / (stem + '.stdout')).write_text(result.stdout)
        (self.out / 'commands' / (stem + '.stderr')).write_text(result.stderr)
        self.log.write('--- stdout ---\n' + result.stdout + '--- stderr ---\n' + result.stderr)
        self.log.write(f'--- exit: {result.returncode} ---\n')
        ok = result.returncode == expected
        if contains is not None:
            ok = ok and contains in (result.stdout + result.stderr)
        (self.out / 'commands' / (stem + '.json')).write_text(json.dumps({
            'argv': args, 'stdin_file': stem + '.stdin.sql' if stdin is not None else None,
            'exit_code': result.returncode, 'expected_exit_code': expected,
            'required_substring': contains, 'expectation_met': ok
        }, indent=2) + '\n')
        if not ok:
            raise RuntimeError(f'Command {stem} failed its expectation: {rendered}; see transcript')
        return result, stem

    def sql(self, container, database, sql, expected=0, contains=None):
        return self.command(['docker', 'exec', '-i', container, 'psql', '-X', '-q', '-A', '-t',
                             '-h', '/lab/socket', '-U', 'postgres', '-d', database,
                             '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose'],
                            sql + '\n', expected, contains)

    def check(self, name, container, db, query):
        result, cmd = self.sql(container, db, query)
        ok = result.stdout.strip() == 't'
        self.rows.append({'check': name, 'status': 'PASS' if ok else 'FAIL', 'command': cmd})
        print(f'{self.rows[-1]["status"]}: {name}', flush=True)
        if not ok:
            raise RuntimeError(f'Assertion failed: {name}: {result.stdout!r}')

    def denied(self, name, container, db, role, query, message):
        _, cmd = self.sql(container, db, f'SET ROLE {role};\n{query}', 3, message)
        # Every SQL denial must also be the permission-denied SQLSTATE.
        stderr = (self.out / 'commands' / (cmd + '.stderr')).read_text()
        if '42501:' not in stderr:
            raise RuntimeError(f'{name}: SQLSTATE 42501 absent')
        self.rows.append({'check': name, 'status': 'PASS', 'command': cmd,
                          'expected_failure': message, 'sqlstate': '42501'})
        print(f'PASS (expected denial): {name}', flush=True)

    def access(self, name, c, db, role, table):
        self.check(name + ': effective role', c, db,
                   f"SET ROLE {role}; SELECT current_user = '{role}' AND NOT "
                   f"(SELECT rolsuper FROM pg_roles WHERE rolname = current_user);")
        self.check(name + ': SELECT', c, db,
                   f'SET ROLE {role}; SELECT count(*) >= 0 FROM app.{table};')
        self.check(name + ': generated INSERT and RETURNING', c, db,
                   f"SET ROLE {role}; BEGIN; INSERT INTO app.{table}(payload) "
                   f"VALUES ('synthetic-probe') RETURNING id > 0; ROLLBACK;")
        self.check(name + ': table and sequence rights', c, db,
                   f"SELECT has_table_privilege('{role}','app.{table}','SELECT') "
                   f"AND has_table_privilege('{role}','app.{table}','INSERT') "
                   f"AND has_sequence_privilege('{role}','app.{table}_id_seq','USAGE') "
                   f"AND NOT has_table_privilege('{role}','app.{table}','UPDATE') "
                   f"AND NOT has_table_privilege('{role}','app.{table}','DELETE') "
                   f"AND NOT has_sequence_privilege('{role}','app.{table}_id_seq','UPDATE');")

    def create_cluster(self, suffix):
        name = self.prefix + '-' + suffix
        # Record the intended name before launch, so timeout/interrupt cleanup
        # can still remove a container created before the client returned.
        self.containers.append(name)
        self.command(['docker', 'run', '--detach', '--name', name, '--platform', PLATFORM,
                      '--network', 'none', '--user', 'postgres', '--tmpfs', '/lab:rw,mode=1777',
                      '--entrypoint', 'sleep', IMAGE, 'infinity'])
        self.command(['docker', 'exec', name, 'mkdir', '-m', '700', '/lab/data', '/lab/socket'])
        self.command(['docker', 'exec', name, 'initdb', '-D', '/lab/data',
                      '--auth-local=peer', '--auth-host=reject', '--encoding=UTF8', '--locale=C'])
        self.command(['docker', 'exec', name, 'pg_ctl', '-D', '/lab/data', '-l', '/lab/server.log',
                      '-o', "-k /lab/socket -c listen_addresses=''", '-w', 'start'])
        return name

    def restore(self, c, db, *options, expected=0, contains=None):
        return self.command(['docker', 'exec', c, 'pg_restore', '-h', '/lab/socket', '-U', 'postgres',
                             '--dbname', db, '--single-transaction', '--exit-on-error',
                             *options, '/lab/source.dump'], expected=expected, contains=contains)

    def run(self):
        self.command(['docker', 'version'])
        self.command(['docker', 'image', 'inspect', IMAGE, '--format',
                      '{{json .RepoDigests}} {{.Id}} {{.Os}}/{{.Architecture}}'])
        src = self.create_cluster('source')
        dst = self.create_cluster('target')
        for binary in ['postgres', 'psql', 'pg_dump', 'pg_restore']:
            self.command(['docker', 'exec', src, binary, '--version'], contains='18.4')
        self.command(['docker', 'exec', src, 'cat', '/etc/os-release'])
        self.check('server pinned to 18.4', src, 'postgres',
                   "SELECT current_setting('server_version_num') = '180004';")
        for c in [src, dst]:
            self.check('server version is 180004: ' + ('source' if c == src else 'target'), c, 'postgres',
                       "SELECT current_setting('server_version_num') = '180004';")
            self.check('no TCP listener: ' + ('source' if c == src else 'target'), c, 'postgres',
                       "SELECT current_setting('listen_addresses') = ''; ")
        self.sql(src, 'postgres', 'CREATE DATABASE lab_source TEMPLATE template0;')
        self.sql(src, 'lab_source', (ROOT / 'sql/source.sql').read_text())
        self.check('source has two synthetic rows', src, 'lab_source',
                   "SELECT array_agg(payload ORDER BY id) = ARRAY['synthetic-alpha','synthetic-beta'] FROM app.widgets;")
        self.command(['docker', 'exec', src, 'pg_dump', '-h', '/lab/socket', '-U', 'postgres',
                      '--format=custom', '--file=/lab/source.dump', 'lab_source'])
        archive, _ = self.command(['docker', 'exec', src, 'base64', '-w', '0', '/lab/source.dump'])
        (self.out / 'source.dump').write_bytes(base64.b64decode(archive.stdout, validate=True))
        self.command(['docker', 'exec', '-i', dst, 'sh', '-c', 'base64 -d > /lab/source.dump'],
                     stdin=archive.stdout)
        digest = hashlib.sha256((self.out / 'source.dump').read_bytes()).hexdigest()
        self.command(['docker', 'exec', dst, 'sha256sum', '/lab/source.dump'], contains=digest)
        listing, _ = self.command(['docker', 'exec', dst, 'pg_restore', '--list', '/lab/source.dump'])
        (self.out / 'archive-list.txt').write_text(listing.stdout)
        rendered, _ = self.command(['docker', 'exec', dst, 'pg_restore', '--file=-', '/lab/source.dump'])
        (self.out / 'archive.sql').write_text(rendered.stdout)
        self.sql(src, 'lab_source', (ROOT / 'sql/inventory.sql').read_text())
        self.sql(dst, 'postgres', '''CREATE ROLE target_owner NOLOGIN;
CREATE ROLE target_app NOLOGIN;
CREATE ROLE migration_role NOLOGIN;
CREATE DATABASE lab_preserved TEMPLATE template0;
CREATE DATABASE lab_owner_only TEMPLATE template0;
CREATE DATABASE lab_remapped OWNER target_owner TEMPLATE template0;''')
        _, cmd = self.restore(dst, 'lab_preserved', expected=1,
                              contains='role "legacy_owner" does not exist')
        self.rows.append({'check':'preserve requires source roles', 'status':'PASS', 'command':cmd,
                          'expected_failure':'role "legacy_owner" does not exist'})
        self.check('failed preserve restored no schema (transaction rolled back)', dst, 'lab_preserved',
                   "SELECT NOT EXISTS (SELECT FROM pg_namespace WHERE nspname='app');")
        self.sql(dst, 'postgres', 'CREATE ROLE legacy_owner NOLOGIN; CREATE ROLE legacy_app NOLOGIN;')
        self.restore(dst, 'lab_preserved')
        self.check('preserved object ownership', dst, 'lab_preserved',
                   "SELECT (SELECT pg_get_userbyid(nspowner)='legacy_owner' FROM pg_namespace WHERE nspname='app') "
                   "AND bool_and(pg_get_userbyid(c.relowner)='legacy_owner') FROM pg_class c "
                   "JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='app';")
        self.check('preserved creator default ACLs', dst, 'lab_preserved',
                   "SELECT count(*)=2 AND bool_and(pg_get_userbyid(defaclrole)='legacy_owner') FROM pg_default_acl;")
        self.access('preserved existing table', dst, 'lab_preserved', 'legacy_app', 'widgets')
        self.sql(dst, 'lab_preserved', 'SET ROLE legacy_owner; CREATE TABLE app.future_widgets '
                 '(id bigserial PRIMARY KEY, payload text NOT NULL);')
        self.access('preserved future table', dst, 'lab_preserved', 'legacy_app', 'future_widgets')
        self.sql(dst, 'lab_preserved', (ROOT / 'sql/inventory.sql').read_text())

        # Diagnostic only: suppressing owners does not suppress or translate grants.
        self.restore(dst, 'lab_owner_only', '--no-owner')
        self.check('no-owner alone uses restoring role for object owner', dst, 'lab_owner_only',
                   "SELECT bool_and(pg_get_userbyid(c.relowner)='postgres') FROM pg_class c "
                   "JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='app';")
        self.check('no-owner alone retains legacy grantee', dst, 'lab_owner_only',
                   "SELECT has_table_privilege('legacy_app','app.widgets','SELECT') "
                   "AND NOT has_table_privilege('target_app','app.widgets','SELECT');")
        self.check('no-owner alone retains legacy default-ACL creator', dst, 'lab_owner_only',
                   "SELECT count(*)=2 AND bool_and(pg_get_userbyid(defaclrole)='legacy_owner') FROM pg_default_acl;")
        self.denied('no-owner alone does not map target_app', dst, 'lab_owner_only', 'target_app',
                    'SELECT * FROM app.widgets;', 'permission denied for schema app')
        self.access('no-owner alone retains old app access', dst, 'lab_owner_only', 'legacy_app', 'widgets')
        self.sql(dst, 'lab_owner_only', 'CREATE TABLE app.owner_only_future '
                 '(id bigserial PRIMARY KEY, payload text NOT NULL);')
        self.denied('old creator defaults do not apply to restoring role', dst, 'lab_owner_only', 'legacy_app',
                    'SELECT * FROM app.owner_only_future;', 'permission denied for table owner_only_future')
        self.check('old creator defaults do not grant new sequence usage', dst, 'lab_owner_only',
                   "SELECT NOT has_sequence_privilege('legacy_app','app.owner_only_future_id_seq','USAGE');")
        self.sql(dst, 'lab_owner_only', (ROOT / 'sql/inventory.sql').read_text())

        self.restore(dst, 'lab_remapped', '--no-owner', '--no-acl', '--role=target_owner')
        self.check('remapped schema and all relations owned by target_owner', dst, 'lab_remapped',
                   "SELECT (SELECT pg_get_userbyid(nspowner)='target_owner' FROM pg_namespace WHERE nspname='app') "
                   "AND bool_and(pg_get_userbyid(c.relowner)='target_owner') FROM pg_class c "
                   "JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='app';")
        self.check('no-acl excludes source default ACLs and source application grants', dst, 'lab_remapped',
                   "SELECT NOT EXISTS(SELECT FROM pg_default_acl) "
                   "AND NOT has_schema_privilege('legacy_app','app','USAGE') "
                   "AND NOT has_table_privilege('legacy_app','app.widgets','SELECT') "
                   "AND NOT has_sequence_privilege('legacy_app','app.widgets_id_seq','USAGE');")
        self.denied('remap before schema grant', dst, 'lab_remapped', 'target_app',
                    'SELECT * FROM app.widgets;', 'permission denied for schema app')
        self.sql(dst, 'lab_remapped', 'SET ROLE target_owner; GRANT USAGE ON SCHEMA app TO target_app;')
        self.denied('schema usage is not table SELECT', dst, 'lab_remapped', 'target_app',
                    'SELECT * FROM app.widgets;', 'permission denied for table widgets')
        self.sql(dst, 'lab_remapped', 'SET ROLE target_owner; GRANT SELECT, INSERT ON TABLE app.widgets TO target_app;')
        self.check('table SELECT after scoped grant', dst, 'lab_remapped',
                   'SET ROLE target_app; SELECT count(*)=2 FROM app.widgets;')
        self.denied('table INSERT does not grant sequence usage', dst, 'lab_remapped', 'target_app',
                    "INSERT INTO app.widgets(payload) VALUES ('synthetic-denied');", 'permission denied for sequence widgets_id_seq')
        self.sql(dst, 'lab_remapped', 'SET ROLE target_owner; GRANT USAGE ON SEQUENCE app.widgets_id_seq TO target_app;')
        self.access('remapped existing table', dst, 'lab_remapped', 'target_app', 'widgets')
        self.denied('app cannot UPDATE table', dst, 'lab_remapped', 'target_app',
                    "UPDATE app.widgets SET payload='synthetic-denied' WHERE id=1;", 'permission denied for table widgets')
        self.denied('app cannot DELETE table', dst, 'lab_remapped', 'target_app',
                    'DELETE FROM app.widgets WHERE id=1;', 'permission denied for table widgets')
        self.denied('app cannot setval sequence', dst, 'lab_remapped', 'target_app',
                    "SELECT setval('app.widgets_id_seq',1000);", 'permission denied for sequence widgets_id_seq')
        self.denied('app cannot CREATE in schema', dst, 'lab_remapped', 'target_app',
                    'CREATE TABLE app.forbidden(id integer);', 'permission denied for schema app')
        self.sql(dst, 'lab_remapped', 'SET ROLE target_owner; CREATE TABLE app.early_widgets '
                 '(id bigserial PRIMARY KEY, payload text NOT NULL);')
        self.denied('new table without defaults', dst, 'lab_remapped', 'target_app',
                    'SELECT * FROM app.early_widgets;', 'permission denied for table early_widgets')
        self.sql(dst, 'lab_remapped', '''SET ROLE target_owner;
ALTER DEFAULT PRIVILEGES FOR ROLE target_owner IN SCHEMA app GRANT SELECT, INSERT ON TABLES TO target_app;
ALTER DEFAULT PRIVILEGES FOR ROLE target_owner IN SCHEMA app GRANT USAGE ON SEQUENCES TO target_app;''')
        self.denied('defaults do not repair pre-existing table', dst, 'lab_remapped', 'target_app',
                    'SELECT * FROM app.early_widgets;', 'permission denied for table early_widgets')
        self.check('defaults do not repair pre-existing sequence', dst, 'lab_remapped',
                   "SELECT NOT has_sequence_privilege('target_app','app.early_widgets_id_seq','USAGE');")
        self.sql(dst, 'lab_remapped', '''SET ROLE target_owner;
GRANT SELECT, INSERT ON TABLE app.early_widgets TO target_app;
GRANT USAGE ON SEQUENCE app.early_widgets_id_seq TO target_app;
CREATE TABLE app.future_widgets (id bigserial PRIMARY KEY, payload text NOT NULL);''')
        self.access('explicitly repaired early table', dst, 'lab_remapped', 'target_app', 'early_widgets')
        self.access('remapped future owner-created table', dst, 'lab_remapped', 'target_app', 'future_widgets')
        self.check('target defaults belong to target_owner only', dst, 'lab_remapped',
                   "SELECT count(*)=2 AND bool_and(pg_get_userbyid(defaclrole)='target_owner') FROM pg_default_acl;")

        self.sql(dst, 'postgres', 'GRANT target_owner TO migration_role;')
        self.sql(dst, 'lab_remapped', 'SET ROLE migration_role; CREATE TABLE app.migration_widgets '
                 '(id bigserial PRIMARY KEY, payload text NOT NULL);')
        self.check('membership does not change creating role', dst, 'lab_remapped',
                   "SELECT pg_get_userbyid(relowner)='migration_role' FROM pg_class WHERE oid='app.migration_widgets'::regclass;")
        self.denied('owner defaults are not inherited by a member creator', dst, 'lab_remapped', 'target_app',
                    'SELECT * FROM app.migration_widgets;', 'permission denied for table migration_widgets')
        # SET SESSION AUTHORIZATION prevents the original administrator from making
        # the tested SET ROLE succeed merely because it is a superuser session.
        self.sql(dst, 'lab_remapped', '''SET SESSION AUTHORIZATION migration_role;
SET ROLE target_owner;
CREATE TABLE app.migration_fixed_widgets (id bigserial PRIMARY KEY, payload text NOT NULL);''')
        self.check('migration SET ROLE creates as default-ACL owner', dst, 'lab_remapped',
                   "SELECT pg_get_userbyid(relowner)='target_owner' FROM pg_class WHERE oid='app.migration_fixed_widgets'::regclass;")
        self.access('migration with explicit owner role', dst, 'lab_remapped', 'target_app', 'migration_fixed_widgets')
        self.sql(dst, 'lab_remapped', '''SET ROLE migration_role;
GRANT SELECT, INSERT ON TABLE app.migration_widgets TO target_app;
GRANT USAGE ON SEQUENCE app.migration_widgets_id_seq TO target_app;''')
        self.access('explicitly repaired migration table', dst, 'lab_remapped', 'target_app', 'migration_widgets')
        for db in ['lab_preserved', 'lab_owner_only', 'lab_remapped']:
            self.check(db + ' retains exactly the original data', dst, db,
                       "SELECT array_agg(payload ORDER BY id)=ARRAY['synthetic-alpha','synthetic-beta'] FROM app.widgets;")
        self.check('app has no owner-role membership or elevated attributes', dst, 'lab_remapped',
                   "SELECT NOT pg_has_role('target_app','target_owner','MEMBER') "
                   "AND NOT pg_has_role('target_app','migration_role','MEMBER') "
                   "AND NOT rolsuper AND NOT rolcreaterole AND NOT rolcreatedb AND NOT rolbypassrls AND NOT rolcanlogin "
                   "FROM pg_roles WHERE rolname='target_app';")
        self.sql(dst, 'lab_remapped', (ROOT / 'sql/inventory.sql').read_text())

    def finish(self, error):
        for c in self.containers:
            try:
                server_log, _ = self.command(['docker', 'exec', c, 'cat', '/lab/server.log'])
                (self.out / (c.rsplit('-',1)[-1] + '-server.log')).write_text(server_log.stdout)
            except Exception as e:
                self.log.write('Log capture failure: ' + str(e) + '\n')
            try:
                self.command(['docker', 'rm', '--force', '--volumes', c])
            except Exception as e:
                error = error or str(e)
        # Listing names is non-mutating; only our exact random names are ever removed.
        try:
            result, cmd = self.command(['docker', 'ps', '-a', '--filter', 'name=' + self.prefix,
                                       '--format', '{{.Names}}'])
            cleanup_ok = not result.stdout.strip()
        except Exception as e:
            cmd = f'{self.n:03d}'
            cleanup_ok = False
            error = error or 'Unable to verify container cleanup: ' + repr(e)
        self.rows.append({'check':'disposable containers and anonymous volumes removed',
                          'status':'PASS' if cleanup_ok else 'FAIL', 'command':cmd})
        if not cleanup_ok:
            error = error or 'Container cleanup failed'
        report = {'status': 'FAIL' if error else 'PASS', 'error': error,
                  'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                  'image': IMAGE, 'platform': PLATFORM,
                  'check_count': len(self.rows), 'checks': self.rows}
        (self.out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
        with (self.out / 'checklist.tsv').open('w') as f:
            f.write('status\tcommand\tcheck\n')
            for row in self.rows:
                f.write(f'{row["status"]}\t{row["command"]}\t{row["check"]}\n')
        self.log.close()
        with (self.out / 'SHA256SUMS').open('w') as f:
            for p in sorted(self.out.rglob('*')):
                if p.is_file() and p.name != 'SHA256SUMS':
                    f.write(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + str(p.relative_to(self.out)) + '\n')
        print(json.dumps({k:report[k] for k in ['status','error','check_count','completed_utc']}))
        return not error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=pathlib.Path, required=True,
                        help='New directory; refuses to overwrite an existing run')
    args = parser.parse_args()
    lab = Lab(args.output)
    error = None
    try:
        lab.run()
    except (Exception, KeyboardInterrupt) as e:
        error = repr(e)
        print(error, file=sys.stderr)
    finally:
        success = lab.finish(error)
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
