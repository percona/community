SET ROLE target_owner; GRANT USAGE ON SEQUENCE app.widgets_id_seq TO target_app;
