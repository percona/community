SET ROLE legacy_owner; CREATE TABLE app.future_widgets (id bigserial PRIMARY KEY, payload text NOT NULL);
