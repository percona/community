SELECT has_table_privilege('legacy_app','app.widgets','SELECT') AND NOT has_table_privilege('target_app','app.widgets','SELECT');
