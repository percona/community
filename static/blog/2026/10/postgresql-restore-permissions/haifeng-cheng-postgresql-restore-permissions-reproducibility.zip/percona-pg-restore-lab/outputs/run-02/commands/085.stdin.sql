SET ROLE migration_role; CREATE TABLE app.migration_widgets (id bigserial PRIMARY KEY, payload text NOT NULL);
