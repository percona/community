CREATE ROLE legacy_owner NOLOGIN;
CREATE ROLE legacy_app NOLOGIN;
CREATE SCHEMA app AUTHORIZATION legacy_owner;
SET ROLE legacy_owner;
CREATE TABLE app.widgets (id bigserial PRIMARY KEY, payload text NOT NULL);
INSERT INTO app.widgets(payload) VALUES ('synthetic-alpha'), ('synthetic-beta');
GRANT USAGE ON SCHEMA app TO legacy_app;
GRANT SELECT, INSERT ON TABLE app.widgets TO legacy_app;
GRANT USAGE ON SEQUENCE app.widgets_id_seq TO legacy_app;
ALTER DEFAULT PRIVILEGES FOR ROLE legacy_owner IN SCHEMA app
  GRANT SELECT, INSERT ON TABLES TO legacy_app;
ALTER DEFAULT PRIVILEGES FOR ROLE legacy_owner IN SCHEMA app
  GRANT USAGE ON SEQUENCES TO legacy_app;
RESET ROLE;
