SET ROLE target_app; BEGIN; INSERT INTO app.widgets(payload) VALUES ('synthetic-probe') RETURNING id > 0; ROLLBACK;
