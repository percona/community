SELECT pg_get_userbyid(relowner)='migration_role' FROM pg_class WHERE oid='app.migration_widgets'::regclass;
