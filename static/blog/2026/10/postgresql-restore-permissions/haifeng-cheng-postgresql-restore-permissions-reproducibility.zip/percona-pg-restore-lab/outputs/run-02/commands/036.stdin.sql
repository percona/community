SET ROLE legacy_app; SELECT current_user = 'legacy_app' AND NOT (SELECT rolsuper FROM pg_roles WHERE rolname = current_user);
