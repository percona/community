SET ROLE target_owner;
GRANT SELECT, INSERT ON TABLE app.early_widgets TO target_app;
GRANT USAGE ON SEQUENCE app.early_widgets_id_seq TO target_app;
CREATE TABLE app.future_widgets (id bigserial PRIMARY KEY, payload text NOT NULL);
