SELECT current_database(), current_user, session_user, version();
SELECT n.nspname, pg_get_userbyid(n.nspowner) AS owner, n.nspacl
FROM pg_namespace n WHERE n.nspname = 'app';
SELECT c.relname, c.relkind, pg_get_userbyid(c.relowner) AS owner, c.relacl
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'app' ORDER BY c.relname;
SELECT pg_get_userbyid(d.defaclrole) AS creator, n.nspname,
       d.defaclobjtype, d.defaclacl
FROM pg_default_acl d LEFT JOIN pg_namespace n ON n.oid = d.defaclnamespace
ORDER BY creator, n.nspname, d.defaclobjtype;
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin,
       rolbypassrls
FROM pg_roles WHERE rolname IN
('legacy_owner','legacy_app','target_owner','target_app','migration_role')
ORDER BY rolname;

