SELECT bool_and(pg_get_userbyid(c.relowner)='postgres') FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='app';
