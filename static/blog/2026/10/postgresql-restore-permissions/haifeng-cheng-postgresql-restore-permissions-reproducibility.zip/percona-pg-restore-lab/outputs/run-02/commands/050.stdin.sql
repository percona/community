SET ROLE target_app;
SELECT * FROM app.widgets;
