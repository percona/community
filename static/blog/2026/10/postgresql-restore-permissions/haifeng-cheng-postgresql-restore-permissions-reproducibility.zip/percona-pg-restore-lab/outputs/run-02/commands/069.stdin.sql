SET ROLE target_app;
CREATE TABLE app.forbidden(id integer);
