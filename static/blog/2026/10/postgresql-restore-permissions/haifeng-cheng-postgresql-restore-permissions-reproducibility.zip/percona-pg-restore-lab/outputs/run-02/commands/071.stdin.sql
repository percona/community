SET ROLE target_app;
SELECT * FROM app.early_widgets;
