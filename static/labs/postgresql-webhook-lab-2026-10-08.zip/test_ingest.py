"""Real PostgreSQL tests. Every test gets a disposable, random schema."""
import os
import time
import unittest
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from threading import Barrier

import psycopg2
from psycopg2 import sql

from ingest import Event, ReusedEventId, ReusedRevision, apply_in_transaction, ingest


DSN = os.environ.get("LAB_DSN")


class WebhookLab(unittest.TestCase):
    def setUp(self):
        if not DSN:
            self.fail("Set LAB_DSN to a disposable PostgreSQL database")
        self.schema = "webhook_lab_" + uuid.uuid4().hex
        self.connections = []
        self.admin = psycopg2.connect(DSN)
        self.admin.autocommit = True
        with self.admin.cursor() as cur:
            cur.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(self.schema)))
            cur.execute(sql.SQL("SET search_path TO {}").format(sql.Identifier(self.schema)))
            cur.execute(Path(__file__).with_name("schema.sql").read_text())

    def tearDown(self):
        for conn in self.connections:
            conn.close()
        with self.admin.cursor() as cur:
            cur.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(self.schema)))
        self.admin.close()

    def connect(self):
        conn = psycopg2.connect(DSN)
        conn.set_session(isolation_level="READ COMMITTED")
        with conn, conn.cursor() as cur:
            cur.execute(sql.SQL("SET search_path TO {}").format(sql.Identifier(self.schema)))
            cur.execute("SET statement_timeout = '10s'")
        self.connections.append(conn)
        return conn

    def event(self, revision=1, event_id=None, source="shop", object_id="order-1"):
        return Event(source, event_id or f"event-{revision}", object_id, revision,
                     {"status": f"state-{revision}", "total_cents": revision * 100})

    def rows(self, query):
        with self.admin.cursor() as cur:
            cur.execute(query)
            return cur.fetchall()

    def state(self):
        return self.rows("SELECT source, object_id, revision, snapshot FROM object_state ORDER BY source, object_id")

    def inbox_count(self):
        return self.rows("SELECT count(*) FROM webhook_inbox")[0][0]

    def wait_until_blocked(self, waiter, blocker):
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            with self.admin.cursor() as cur:
                cur.execute("SELECT %s = ANY(pg_blocking_pids(%s))",
                            (blocker.get_backend_pid(), waiter.get_backend_pid()))
                if cur.fetchone()[0]:
                    return
            time.sleep(0.01)
        self.fail("Expected a real PostgreSQL lock wait; it was not observed")

    def test_01_sequential_retries(self):
        conn = self.connect()
        self.assertEqual(ingest(conn, self.event()), "applied")
        self.assertEqual(ingest(conn, self.event()), "duplicate")
        self.assertEqual(self.inbox_count(), 1)
        self.assertEqual(self.state()[0][2], 1)

    def test_02_parallel_duplicate_waits_for_commit(self):
        first, second = self.connect(), self.connect()
        apply_in_transaction(first, self.event())
        with ThreadPoolExecutor(1) as pool:
            pending = pool.submit(ingest, second, self.event())
            try:
                self.wait_until_blocked(second, first)
                self.assertEqual(self.state(), [])
            finally:
                first.commit()
            self.assertEqual(pending.result(timeout=10), "duplicate")
        self.assertEqual(self.inbox_count(), 1)

    def test_03_parallel_duplicate_takes_over_after_rollback(self):
        first, second = self.connect(), self.connect()
        apply_in_transaction(first, self.event())
        with ThreadPoolExecutor(1) as pool:
            pending = pool.submit(ingest, second, self.event())
            try:
                self.wait_until_blocked(second, first)
            finally:
                first.rollback()
            self.assertEqual(pending.result(timeout=10), "applied")
        self.assertEqual(self.inbox_count(), 1)

    def test_04_out_of_order_snapshots(self):
        conn = self.connect()
        self.assertEqual(ingest(conn, self.event(3)), "applied")
        self.assertEqual(ingest(conn, self.event(1)), "stale")
        self.assertEqual(ingest(conn, self.event(2)), "stale")
        self.assertEqual(self.state()[0][2:], (3, self.event(3).snapshot))
        self.assertEqual(self.inbox_count(), 3)

    def test_05_concurrent_revisions_both_lock_orders(self):
        for earlier, later in [(2, 1), (3, 4)]:
            first, second = self.connect(), self.connect()
            obj = f"order-{earlier}"
            apply_in_transaction(first, self.event(earlier, object_id=obj))
            with ThreadPoolExecutor(1) as pool:
                pending = pool.submit(ingest, second, self.event(later, object_id=obj))
                try:
                    self.wait_until_blocked(second, first)
                finally:
                    first.commit()
                self.assertEqual(pending.result(timeout=10), "stale" if later < earlier else "applied")
        self.assertEqual([row[2] for row in self.state()], [2, 4])

    def test_06_disconnect_before_commit_rolls_back_both_tables(self):
        conn = self.connect()
        apply_in_transaction(conn, self.event())
        conn.close()
        self.assertEqual(ingest(self.connect(), self.event()), "applied")
        self.assertEqual(self.inbox_count(), 1)
        self.assertEqual(len(self.state()), 1)

    def test_07_commit_then_lost_ack_is_safe_to_retry(self):
        conn = self.connect()
        apply_in_transaction(conn, self.event())
        conn.commit()
        conn.close()  # Treat the sender as having received no HTTP response.
        self.assertEqual(ingest(self.connect(), self.event()), "duplicate")
        self.assertEqual(self.inbox_count(), 1)

    def test_08_event_id_collision_is_rejected(self):
        conn = self.connect()
        ingest(conn, self.event())
        with self.assertRaises(ReusedEventId):
            ingest(conn, self.event(2, event_id="event-1"))
        self.assertEqual(self.inbox_count(), 1)
        self.assertEqual(self.state()[0][2], 1)

    def test_09_revision_collision_is_rejected(self):
        conn = self.connect()
        ingest(conn, self.event())
        with self.assertRaises(ReusedRevision):
            ingest(conn, self.event(1, event_id="another-event"))
        self.assertEqual(self.inbox_count(), 1)
        self.assertEqual(self.state()[0][2], 1)

    def test_10_source_namespace_is_separate(self):
        conn = self.connect()
        ingest(conn, self.event(source="shop-a"))
        ingest(conn, self.event(source="shop-b"))
        self.assertEqual(self.inbox_count(), 2)
        self.assertEqual(len(self.state()), 2)

    def test_11_many_parallel_retries_and_revisions(self):
        events = [self.event(n) for n in [6, 2, 8, 1, 4, 3, 7, 5]] * 3
        barrier = Barrier(len(events))
        connections = [self.connect() for _ in events]

        def deliver(conn, event):
            barrier.wait(timeout=10)
            return ingest(conn, event)

        with ThreadPoolExecutor(len(events)) as pool:
            futures = [pool.submit(deliver, conn, event)
                       for conn, event in zip(connections, events)]
            results = [f.result(timeout=15) for f in futures]
        self.assertEqual(results.count("duplicate"), 16)
        self.assertEqual(self.inbox_count(), 8)
        self.assertEqual(self.state()[0][2:], (8, self.event(8).snapshot))

    def test_12_invalid_snapshot_does_not_commit_inbox(self):
        conn = self.connect()
        bad = Event("shop", "bad", "order-1", 1, ["not-an-object"])
        with self.assertRaises(psycopg2.errors.CheckViolation):
            ingest(conn, bad)
        self.assertEqual(self.inbox_count(), 0)
        self.assertEqual(self.state(), [])

    def test_13_json_boolean_is_not_the_number_one(self):
        conn = self.connect()
        ingest(conn, Event("shop", "typed", "order-1", 1, {"value": True}))
        with self.assertRaises(ReusedEventId):
            ingest(conn, Event("shop", "typed", "order-1", 1, {"value": 1}))
        self.assertEqual(self.inbox_count(), 1)
        self.assertIs(self.state()[0][3]["value"], True)


if __name__ == "__main__":
    if DSN:
        with closing(psycopg2.connect(DSN)) as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT version()")
                print(cursor.fetchone()[0], flush=True)
        print("psycopg2", psycopg2.__version__, flush=True)
    unittest.main(verbosity=2)
