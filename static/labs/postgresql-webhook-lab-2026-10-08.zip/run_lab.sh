#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

LAB_PYTHON="${LAB_PYTHON:-python3}"
if ! "$LAB_PYTHON" -c 'import psycopg2' 2>/dev/null; then
  echo 'Install requirements.txt in a virtual environment first (see README.md).' >&2
  exit 1
fi

LAB_IMAGE='postgres@sha256:fe03a7605299a34ddf5e4f285dff78c3d7190a576b3c6b46f2fcff69f4bffd54'
LAB_CONTAINER="percona-webhook-lab-$(date +%s)-$$"
cleanup() { docker stop "$LAB_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT
docker run --detach --rm --name "$LAB_CONTAINER" \
  --memory 512m --cpus 2 --tmpfs /var/lib/postgresql/data \
  -e POSTGRES_USER=webhook_lab -e POSTGRES_PASSWORD=local_lab_only \
  -e POSTGRES_DB=webhook_lab -p 127.0.0.1::5432 "$LAB_IMAGE" >/dev/null

LAB_READY=0
for attempt in {1..60}; do
  if docker exec "$LAB_CONTAINER" pg_isready -h 127.0.0.1 -U webhook_lab -d webhook_lab >/dev/null 2>&1; then
    LAB_READY=1
    break
  fi
  sleep 1
done
if [ "$LAB_READY" -ne 1 ]; then
  docker logs "$LAB_CONTAINER" >&2
  exit 1
fi
LAB_PORT="$(docker port "$LAB_CONTAINER" 5432/tcp | sed -n 's/^127\.0\.0\.1://p')"
export LAB_DSN="host=127.0.0.1 port=$LAB_PORT dbname=webhook_lab user=webhook_lab password=local_lab_only"
"$LAB_PYTHON" test_ingest.py
