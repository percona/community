# PostgreSQL webhook lab

A synthetic laboratory example for retry-safe snapshot ingestion with PostgreSQL. It is not a customer production incident, an end-to-end exactly-once protocol or a throughput benchmark. AI assisted with drafting and checking the material.

## Run

Requires Docker and Python 3.10 or later. No cloud account or paid service is required. The image and driver are pinned to the versions in the recorded verification logs, not recommended as current production patch choices.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
LAB_PYTHON=.venv/bin/python bash run_lab.sh
```

The runner creates and removes its own disposable PostgreSQL container, uses memory-backed storage and binds a random port only to 127.0.0.1. The password local_lab_only belongs only to this disposable lab. Do not run the tests against a production database.

Each test creates and removes its own random schema. The recorded full run passed 13 tests; concurrency-results.txt records 30 repeated concurrency runs. These are historical verification logs, not a fresh test run on 8 October 2026.

## Event contract and limits

- source must be a trusted provider/account namespace established after authentication.
- An event ID identifies the same content on every retry within that source.
- Each object revision belongs to one event ID. Revisions are positive, increasing versions and carry complete snapshots.
- All projection writers must follow the conditional-update transaction path; the inbox is append-only for the guarantee period.
- Connections use READ COMMITTED, autocommit disabled and one event per transaction.
- The receiver does not manufacture ordering where the provider supplies none. Delta/patch events, external email/card effects, transport authentication and production durability need separate designs.

## Files

schema.sql; ingest.py; test_ingest.py; requirements.txt; run_lab.sh; test-results.txt; concurrency-results.txt.
