CREATE TABLE webhook_inbox (
    source text NOT NULL CHECK (source <> ''),
    event_id text NOT NULL CHECK (event_id <> ''),
    object_id text NOT NULL CHECK (object_id <> ''),
    revision bigint NOT NULL CHECK (revision > 0),
    snapshot jsonb NOT NULL CHECK (jsonb_typeof(snapshot) = 'object'),
    received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    PRIMARY KEY (source, event_id),
    UNIQUE (source, object_id, revision)
);

CREATE TABLE object_state (
    source text NOT NULL,
    object_id text NOT NULL,
    revision bigint NOT NULL CHECK (revision > 0),
    snapshot jsonb NOT NULL CHECK (jsonb_typeof(snapshot) = 'object'),
    PRIMARY KEY (source, object_id)
);
