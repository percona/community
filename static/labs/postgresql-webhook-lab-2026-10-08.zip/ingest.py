"""Database transaction core for a synthetic webhook lab, not an HTTP server."""
from dataclasses import dataclass

from psycopg2.extras import Json


@dataclass(frozen=True)
class Event:
    source: str
    event_id: str
    object_id: str
    revision: int
    snapshot: dict


class ReusedEventId(ValueError):
    pass


class ReusedRevision(ValueError):
    pass


def apply_in_transaction(conn, event):
    """Caller owns commit/rollback; must use READ COMMITTED, autocommit=False."""
    values = (event.source, event.event_id, event.object_id,
              event.revision, Json(event.snapshot))
    with conn.cursor() as cur:
        cur.execute("""
            INSERT INTO webhook_inbox
                (source, event_id, object_id, revision, snapshot)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT DO NOTHING
            RETURNING event_id
        """, values)
        if cur.fetchone() is None:
            # Separate statement: a new READ COMMITTED snapshot after a wait.
            cur.execute("""
                SELECT object_id = %s AND revision = %s AND snapshot = %s::jsonb
                FROM webhook_inbox WHERE source = %s AND event_id = %s
            """, (event.object_id, event.revision, Json(event.snapshot),
                  event.source, event.event_id))
            stored = cur.fetchone()
            if stored is None:
                raise ReusedRevision("Another event ID already owns this object revision")
            if not stored[0]:
                raise ReusedEventId("An event ID was reused with different data")
            return "duplicate"

        cur.execute("""
            INSERT INTO object_state AS current
                (source, object_id, revision, snapshot)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (source, object_id) DO UPDATE
                SET revision = EXCLUDED.revision,
                    snapshot = EXCLUDED.snapshot
                WHERE current.revision < EXCLUDED.revision
            RETURNING revision
        """, (event.source, event.object_id, event.revision, Json(event.snapshot)))
        return "applied" if cur.fetchone() else "stale"


def ingest(conn, event):
    """Only return success after the transaction context has committed."""
    with conn:
        result = apply_in_transaction(conn, event)
    return result
